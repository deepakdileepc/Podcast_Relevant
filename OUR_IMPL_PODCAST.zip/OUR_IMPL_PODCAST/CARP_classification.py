import openai

# Set OpenAI API key directly
openai.api_key = "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"  # Replace with your actual API key

def classify_text(input_text, podcast_theme, model="gpt-3.5-turbo-instruct"):
    """
    Classify a text segment as related or non-related to the podcast theme.
    """
    # Step 1: Identify Clues
    clues_prompt = (
        f"Podcast Theme: {podcast_theme}\n"
        "First, list CLUES (e.g., keywords, phrases, contextual information, semantic relations, "
        "semantic meaning, tones, references) that support the determination of whether the input sentence relates to the podcast theme.\n"
        f"Input: {input_text}\n"
        "Clues:"
    )
    clues_response = openai.ChatCompletion.create(
        model=model,
        messages=[{"role": "user", "content": clues_prompt}],
        max_tokens=100,
        temperature=0.7
    )
    clues = clues_response.choices[0].message['content'].strip()

    # Step 2: Diagnostic Reasoning
    reasoning_prompt = (
        f"Podcast Theme: {podcast_theme}\n"
        f"Input: {input_text}\n"
        f"Clues: {clues}\n"
        "Reasoning:"
    )
    reasoning_response = openai.ChatCompletion.create(
        model=model,
        messages=[{"role": "user", "content": reasoning_prompt}],
        max_tokens=130,
        temperature=0.7
    )
    reasoning = reasoning_response.choices[0].message['content'].strip()

    # Step 3: Final Classification
    classification_prompt = (
        f"Podcast Theme: {podcast_theme}\n"
        f"Input: {input_text}\n"
        f"Clues: {clues}\n"
        f"Reasoning: {reasoning}\n"
        "Classification:"
    )
    classification_response = openai.ChatCompletion.create(
        model=model,
        messages=[{"role": "user", "content": classification_prompt}],
        max_tokens=10,
        temperature=0.0
    )
    classification = classification_response.choices[0].message['content'].strip().lower()

    # Determine final classification
    if "yes" in classification:
        return {
            'input_text': input_text,
            'classification': 1,  # Relates to the podcast theme
            'clues': clues,
            'reasoning': reasoning
        }
    elif "no" in classification:
        return {
            'input_text': input_text,
            'classification': 0,  # Does not relate to the podcast theme
            'clues': clues,
            'reasoning': reasoning
        }
    else:
        return {
            'input_text': input_text,
            'classification': None,
            'clues': clues,
            'reasoning': reasoning
        }


def classify_texts(input_texts, podcast_theme, model="gpt-3.5-turbo-instruct"):
    """
    Sequentially classify multiple text segments.
    """
    results = []
    for text in input_texts:
        result = classify_text(text, podcast_theme, model)
        results.append(result)
    return results
